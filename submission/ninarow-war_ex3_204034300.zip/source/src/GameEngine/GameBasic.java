package GameEngine;

public class GameBasic extends Game {
}
