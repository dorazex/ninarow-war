package XmlLoader;

public class ConfigXmlException extends Exception {
    public ConfigXmlException(String message) {
        super(message);
    }
}
